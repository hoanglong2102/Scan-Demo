import React, { useState } from "react";
import { createWorker } from "tesseract.js";
import { useHistory } from "react-router-dom";
import PropTypes from "prop-types";
import Camera, { FACING_MODES } from "react-html5-camera-photo";
import "react-html5-camera-photo/build/css/index.css";

function CameraOldIDCard(props) {
  const [text, setText] = useState("");

  let history = useHistory();

  function handleClick() {
    history.push("/old-id-card");
  }

  const handleTakePhoto = (dataUri) => {
    doOCR(dataUri);
  };

  const worker = createWorker({
    logger: (m) => {
      if (props.showLogsOnConsole) {
        console.log(m);
      }
    },
  });

  const doOCR = async (imageData) => {
    await worker.load();
    await worker.loadLanguage("vie");
    await worker.initialize("vie");
    const {
      data: { text },
    } = await worker.recognize(imageData);
    props.onTextRecognize(text.split("\n"));
    setText(text.split("\n"));
  };

  return (
    <div className="content">
      <h1> Camera Old ID Card</h1>
      <form>
        <label className="radio-inline">
          <input type="radio" name="optradio" onClick={handleClick} />
          <b>File</b>
        </label>
        &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
        <label className="radio-inline">
          <input type="radio" name="optradio" checked /> <b>Camera</b>
        </label>
      </form>
      <Camera
        onTakePhoto={(dataUri) => {
          handleTakePhoto(dataUri);
        }}
        idealFacingMode={FACING_MODES.ENVIRONMENT}
        isFullscreen={props.isFullscreen}
        isImageMirror={props.isImageMirror}
        imageType={props.imageType}
        onCameraStart={props.onCameraStart}
        onCameraStop={props.onCameraStop}
        onCameraError={props.onCameraError}
        onTextRecognize={props.onTextRecognize}
      />
      <p align="center"> Recognized Text - {text || '""'} </p>
    </div>
  );
}

CameraOldIDCard.propTypes = {
  showLogsOnConsole: PropTypes.bool,
  onTextRecognize: PropTypes.func,
  isFullscreen: PropTypes.bool,
  isImageMirror: PropTypes.bool,
  imageType: PropTypes.string,
  onCameraStart: PropTypes.func,
  onCameraStop: PropTypes.func,
  onCameraError: PropTypes.func,
};

CameraOldIDCard.defaultProps = {
  showLogsOnConsole: true,
  onTextRecognize: (text) => {
    console.log("Text: ", text);
  },
  isImageMirror: false,
  isFullscreen: false,
  imageType: "png",
  onCameraStart: () => {},
  onCameraStop: () => {},
  onCameraError: () => {},
};

export default CameraOldIDCard;
