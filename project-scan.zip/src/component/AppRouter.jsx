import React from "react";
import { Route, Switch } from "react-router-dom";
import NewIDCard from "./File/NewIDCard";
import OldIDCard from "./File/OldIDCard";
import Passport from "./File/Passport";
import NewCDL from "./File/NewCDL";
import OldCDL from "./File/OldCDL";
import CameraNewIDCard from "../Camera/CameraNewIDCard";
import CameraNewCDL from "../Camera/CameraNewCDL";
import CameraOldIDCard from "../Camera/CameraOldIDCard";
import CameraOldCDL from "../Camera/CameraOldCDL";

function AppRouter() {
  return (
    <Switch>
      <Route path="/new-id-card">
        <NewIDCard />
      </Route>
      <Route path="/old-id-card">
        <OldIDCard />
      </Route>
      <Route path="/new-car-driver-license">
        <NewCDL />
      </Route>
      <Route path="/old-car-driver-license">
        <OldCDL />
      </Route>
      <Route path="/passport">
        <Passport />
      </Route>
      <Route path="/cam-new-id-card">
        <CameraNewIDCard />
      </Route>
      <Route path="/cam-old-id-card">
        <CameraOldIDCard />
      </Route>
      <Route path="/cam-new-car-driver-license">
        <CameraNewCDL />
      </Route>
      <Route path="/cam-old-car-driver-license">
        <CameraOldCDL />
      </Route>
    </Switch>
  );
}

const style = {
  marginTop: "20px",
};

export default AppRouter;
