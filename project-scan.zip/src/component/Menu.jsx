import React from 'react';
import Typography from '@material-ui/core/Typography';
import Radio from '@material-ui/core/Radio';
import RadioGroup from '@material-ui/core/RadioGroup';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import FormControl from '@material-ui/core/FormControl';
import FormLabel from '@material-ui/core/FormLabel';  
import { useHistory } from 'react-router-dom';


function Menu () {

    const [value, setValue] = React.useState('NewIDCard');

    const handleChange = (event) => {
            setValue(event.target.value);
    };

    let history = useHistory();

    function handleClick1 () {
        history.push("/new-id-card");
    }

    function handleClick2 () {
        history.push("/old-id-card");
    }

    function handleClick3 () {
        history.push("/new-car-driver-license");
    }

    function handleClick4 () {
        history.push("/old-car-driver-license");
    }

    function handleClick5 () {
        history.push("/passport");
    }

    return (
        <div className="menu">
            <FormControl component="fieldset">
                <FormLabel component="legend">
                    <Typography variant="h4">
                        Categories
                    </Typography>
                </FormLabel>
                <RadioGroup aria-label="categories" name="categories" value={value} onChange={handleChange}>
                    <FormControlLabel value="NewIDCard" control={<Radio />} label="New ID Card" 
                    onClick={handleClick1} /> 
                    <FormControlLabel value="OldIDCard" control={<Radio />} label="Old ID Card" onClick={handleClick2}/>
                    <FormControlLabel value="NewCarDriverLicense" control={<Radio />} label="New Car Driver License" onClick={handleClick3}/>
                    <FormControlLabel value="OldDriverDriverLicense" control={<Radio />} label="Old Car Driver License" onClick={handleClick4} />
                    <FormControlLabel value="Passport" control={<Radio />} label="Passport" onClick={handleClick5} />
                </RadioGroup>
            </FormControl>
        </div>
    )
}

export default Menu;
