import React, { Component } from 'react'
import Tesserect from 'tesseract.js'

class Passport extends Component {
    constructor(props) {
        super(props)
        this.state = {
          uploads: [],
          documents: []
        };
      }
      handleChange = (event) => {
        if (event.target.files[0]) {
          var uploads = []
          for (var key in event.target.files) {
            if (!event.target.files.hasOwnProperty(key)) continue;
            let upload = event.target.files[key]
            uploads.push(URL.createObjectURL(upload))
          }
          this.setState({
            uploads: uploads
          })
        } else {
          this.setState({
            uploads: []
          })
        }
      }

      generateText = () => {
        let uploads = this.state.uploads
      
        for(var i = 0; i < uploads.length; i++) {
          Tesserect.recognize(uploads[i],
             'vie',{ logger: m => console.log(m) })
          .catch(err => {
            console.error(err)
          }).then(({ data: { text } }) => {
            console.log(text.split("\n"))
            var arrText = text.split("\n");
            this.setState({ 
              documents: this.state.documents.concat({
                text: arrText
              })
            })
           })
        }
        }

    render() {
    return(
    <div className="content">
        <h1>Passport</h1>
        <form>
            <label className="radio-inline">
                <input type = "radio" name="optradio" checked /><b>File</b>
            </label>
            &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
            <label className="radio-inline">
                <input type = "radio" name="optradio" /> <b>Camera</b>
            </label>
        </form>
        <div>
            <div className="left">
                <h4>Front</h4>
                <input type = "file" id="fileUploader" onChange={this.handleChange} multiple />
                <div>
                    { this.state.uploads.map((value, index) => {
                        return <img key={index} src={value} width="300px" />
                    }) }
                </div>
            </div>
            <button onClick={this.generateText} className="button">Generate</button>
        { this.state.documents.map((value, index) => {
            return (
              <div key={index} className="results__result">
                <div className="results__result__info">
                  <div className="results__result__info__text">
                      <small><strong>Full Output:</strong> <br />
                    { "Document Number: " + value.text[16].substring(0, 8, value.text[16].lenght)}
                    <br />
                    {" Name: " + value.text[15].substring(5,24, value.text[15].lenght) }     
                    <br />                               
                    {" Gender: " + value.text[8].substring(12,13, value.text[8].lenght)}
                    <br />
                    {" Date Of Birth: " + value.text[8].substring(14,22, value.text[8].lenght)}
                    <br />
                    {" Nationally: " + value.text[8].substring(23, value.text[10].lenght)}
                    <br />
                    {" ExpireDay: " + value.text[11].substring(10,20, value.text[11].lenght)}
                        </small>                      
                  </div>
                </div>
              </div>
            )
          }) }
        </div>
    </div>
    );
}
}

export default Passport